import 'package:flutter/material.dart';
import 'package:aakash_s_application1/presentation/login_screen/login_screen.dart';
import 'package:aakash_s_application1/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:aakash_s_application1/presentation/forgot_password_screen/forgot_password_screen.dart';
import 'package:aakash_s_application1/presentation/home_container_screen/home_container_screen.dart';
import 'package:aakash_s_application1/presentation/shopping_screen/shopping_screen.dart';
import 'package:aakash_s_application1/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String loginScreen = '/login_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String forgotPasswordScreen = '/forgot_password_screen';

  static const String homePage = '/home_page';

  static const String homeContainerScreen = '/home_container_screen';

  static const String shoppingScreen = '/shopping_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        loginScreen: LoginScreen.builder,
        signUpScreen: SignUpScreen.builder,
        forgotPasswordScreen: ForgotPasswordScreen.builder,
        homeContainerScreen: HomeContainerScreen.builder,
        shoppingScreen: ShoppingScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: LoginScreen.builder
      };
}
