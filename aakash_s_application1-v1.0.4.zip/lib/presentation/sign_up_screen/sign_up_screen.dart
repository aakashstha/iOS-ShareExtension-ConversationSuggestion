import 'bloc/sign_up_bloc.dart';
import 'models/sign_up_model.dart';
import 'package:aakash_s_application1/core/app_export.dart';
import 'package:aakash_s_application1/core/utils/validation_functions.dart';
import 'package:aakash_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:aakash_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:aakash_s_application1/widgets/custom_elevated_button.dart';
import 'package:aakash_s_application1/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class SignUpScreen extends StatelessWidget {
  SignUpScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<SignUpBloc>(
      create: (context) => SignUpBloc(SignUpState(
        signUpModelObj: SignUpModel(),
      ))
        ..add(SignUpInitialEvent()),
      child: SignUpScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 17.h),
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.only(left: 69.h),
                        child: Text(
                          "lbl_create_account".tr,
                          style: theme.textTheme.displaySmall,
                        ),
                      ),
                    ),
                    SizedBox(height: 60.v),
                    _buildName(context),
                    SizedBox(height: 15.v),
                    _buildEmail(context),
                    SizedBox(height: 15.v),
                    _buildPassword(context),
                    SizedBox(height: 15.v),
                    _buildConfirmPassword(context),
                    SizedBox(height: 50.v),
                    _buildSignUp(context),
                    SizedBox(height: 8.v),
                    Container(
                      width: 299.h,
                      margin: EdgeInsets.symmetric(horizontal: 40.h),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "msg_by_signing_up_you2".tr,
                              style: theme.textTheme.bodyMedium,
                            ),
                            TextSpan(
                              text: "msg_terms_of_service".tr,
                              style:
                                  CustomTextStyles.bodyMediumPrimary.copyWith(
                                decoration: TextDecoration.underline,
                              ),
                            ),
                            TextSpan(
                              text: "lbl_and".tr,
                              style: theme.textTheme.bodyMedium,
                            ),
                            TextSpan(
                              text: "lbl_privacy_policy".tr,
                              style:
                                  CustomTextStyles.bodyMediumPrimary.copyWith(
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildFive(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: double.maxFinite,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgVector,
        margin: EdgeInsets.fromLTRB(22.h, 21.v, 378.h, 21.v),
      ),
    );
  }

  /// Section Widget
  Widget _buildName(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
      selector: (state) => state.nameController,
      builder: (context, nameController) {
        return CustomTextFormField(
          controller: nameController,
          hintText: "lbl_name".tr,
          validator: (value) {
            if (!isText(value)) {
              return "err_msg_please_enter_valid_text".tr;
            }
            return null;
          },
        );
      },
    );
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
      selector: (state) => state.emailController,
      builder: (context, emailController) {
        return CustomTextFormField(
          controller: emailController,
          hintText: "lbl_email".tr,
          textInputType: TextInputType.emailAddress,
          validator: (value) {
            if (value == null || (!isValidEmail(value, isRequired: true))) {
              return "err_msg_please_enter_valid_email".tr;
            }
            return null;
          },
        );
      },
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
      selector: (state) => state.passwordController,
      builder: (context, passwordController) {
        return CustomTextFormField(
          controller: passwordController,
          hintText: "lbl_password".tr,
          textInputType: TextInputType.visiblePassword,
          validator: (value) {
            if (value == null || (!isValidPassword(value, isRequired: true))) {
              return "err_msg_please_enter_valid_password".tr;
            }
            return null;
          },
          obscureText: true,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildConfirmPassword(BuildContext context) {
    return BlocSelector<SignUpBloc, SignUpState, TextEditingController?>(
      selector: (state) => state.confirmPasswordController,
      builder: (context, confirmPasswordController) {
        return CustomTextFormField(
          controller: confirmPasswordController,
          hintText: "msg_confirm_password".tr,
          textInputAction: TextInputAction.done,
          textInputType: TextInputType.visiblePassword,
          validator: (value) {
            if (value == null || (!isValidPassword(value, isRequired: true))) {
              return "err_msg_please_enter_valid_password".tr;
            }
            return null;
          },
          obscureText: true,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildSignUp(BuildContext context) {
    return CustomElevatedButton(
      text: "lbl_sign_up".tr,
    );
  }

  /// Section Widget
  Widget _buildFive(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 103.h,
        right: 103.h,
        bottom: 18.v,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "msg_already_have_an".tr,
            style: CustomTextStyles.bodyLargeBluegray40016,
          ),
          Padding(
            padding: EdgeInsets.only(left: 2.h),
            child: Text(
              "lbl_sign_in".tr,
              style: CustomTextStyles.titleMediumPrimary.copyWith(
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
