import '../models/grid_item_model.dart';
import 'package:aakash_s_application1/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class GridItemWidget extends StatelessWidget {
  GridItemWidget(
    this.gridItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  GridItemModel gridItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 23.h,
        vertical: 14.v,
      ),
      decoration: AppDecoration.outlineBlack.copyWith(
        borderRadius: BorderRadiusStyle.circleBorder50,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 2.v),
          CustomImageView(
            imagePath: gridItemModelObj?.shoppingImage,
            height: 44.adaptSize,
            width: 44.adaptSize,
          ),
          SizedBox(height: 9.v),
          Text(
            gridItemModelObj.shoppingText!,
            style: CustomTextStyles.labelLargeRoboto,
          ),
        ],
      ),
    );
  }
}
