import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/slider_item_model.dart';
import '../models/grid_item_model.dart';
import 'package:aakash_s_application1/presentation/home_page/models/home_model.dart';
part 'home_event.dart';
part 'home_state.dart';

/// A bloc that manages the state of a Home according to the event that is dispatched to it.
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc(HomeState initialState) : super(initialState) {
    on<HomeInitialEvent>(_onInitialize);
  }

  List<SliderItemModel> fillSliderItemList() {
    return List.generate(1, (index) => SliderItemModel());
  }

  List<GridItemModel> fillGridItemList() {
    return [
      GridItemModel(
          shoppingImage: ImageConstant.imgStorefrontFill,
          shoppingText: "Shopping"),
      GridItemModel(
          shoppingImage: ImageConstant.imgEngineeringFil,
          shoppingText: "Contractors"),
      GridItemModel(
          shoppingImage: ImageConstant.imgHotelFill0Wgh, shoppingText: "Rooms"),
      GridItemModel(
          shoppingImage: ImageConstant.imgWorkFill0Wght, shoppingText: "Jobs"),
      GridItemModel(
          shoppingImage: ImageConstant.imgComputerFill0,
          shoppingText: "IT Services")
    ];
  }

  _onInitialize(
    HomeInitialEvent event,
    Emitter<HomeState> emit,
  ) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
      sliderIndex: 0,
    ));
    emit(state.copyWith(
        homeModelObj: state.homeModelObj?.copyWith(
      sliderItemList: fillSliderItemList(),
      gridItemList: fillGridItemList(),
    )));
  }
}
