import '../../../core/app_export.dart';

/// This class is used in the [grid_item_widget] screen.
class GridItemModel {
  GridItemModel({
    this.shoppingImage,
    this.shoppingText,
    this.id,
  }) {
    shoppingImage = shoppingImage ?? ImageConstant.imgStorefrontFill;
    shoppingText = shoppingText ?? "Shopping";
    id = id ?? "";
  }

  String? shoppingImage;

  String? shoppingText;

  String? id;
}
