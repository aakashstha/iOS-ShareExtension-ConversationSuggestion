import '../../../core/app_export.dart';

/// This class is used in the [slider_item_widget] screen.
class SliderItemModel {
  SliderItemModel({this.id}) {
    id = id ?? "";
  }

  String? id;
}
