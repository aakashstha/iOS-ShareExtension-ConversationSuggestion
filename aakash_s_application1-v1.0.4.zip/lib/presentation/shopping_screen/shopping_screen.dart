import '../shopping_screen/widgets/viewhierarchy_item_widget.dart';
import 'bloc/shopping_bloc.dart';
import 'models/shopping_model.dart';
import 'models/viewhierarchy_item_model.dart';
import 'package:aakash_s_application1/core/app_export.dart';
import 'package:aakash_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:aakash_s_application1/widgets/app_bar/appbar_subtitle.dart';
import 'package:aakash_s_application1/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:aakash_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:aakash_s_application1/widgets/custom_search_view.dart';
import 'package:flutter/material.dart';

class ShoppingScreen extends StatelessWidget {
  const ShoppingScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<ShoppingBloc>(
      create: (context) => ShoppingBloc(ShoppingState(
        shoppingModelObj: ShoppingModel(),
      ))
        ..add(ShoppingInitialEvent()),
      child: ShoppingScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray100,
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 22.h,
            vertical: 25.v,
          ),
          child: Column(
            children: [
              BlocSelector<ShoppingBloc, ShoppingState, TextEditingController?>(
                selector: (state) => state.searchController,
                builder: (context, searchController) {
                  return CustomSearchView(
                    controller: searchController,
                    hintText: "lbl_shop_anything".tr,
                  );
                },
              ),
              SizedBox(height: 30.v),
              _buildViewHierarchy(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 71.v,
      leadingWidth: 30.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgBack,
        margin: EdgeInsets.only(
          left: 10.h,
          top: 32.v,
          bottom: 19.v,
        ),
      ),
      centerTitle: true,
      title: AppbarSubtitleOne(
        text: "lbl_shopping".tr,
      ),
      actions: [
        AppbarSubtitle(
          text: "lbl_activity".tr,
          margin: EdgeInsets.fromLTRB(22.h, 33.v, 22.h, 15.v),
        ),
      ],
      styleType: Style.bgShadow,
    );
  }

  /// Section Widget
  Widget _buildViewHierarchy(BuildContext context) {
    return BlocSelector<ShoppingBloc, ShoppingState, ShoppingModel?>(
      selector: (state) => state.shoppingModelObj,
      builder: (context, shoppingModelObj) {
        return GridView.builder(
          shrinkWrap: true,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisExtent: 201.v,
            crossAxisCount: 2,
            mainAxisSpacing: 10.h,
            crossAxisSpacing: 10.h,
          ),
          physics: NeverScrollableScrollPhysics(),
          itemCount: shoppingModelObj?.viewhierarchyItemList.length ?? 0,
          itemBuilder: (context, index) {
            ViewhierarchyItemModel model =
                shoppingModelObj?.viewhierarchyItemList[index] ??
                    ViewhierarchyItemModel();
            return ViewhierarchyItemWidget(
              model,
            );
          },
        );
      },
    );
  }
}
