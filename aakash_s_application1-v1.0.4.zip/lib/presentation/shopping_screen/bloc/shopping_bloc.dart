import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/viewhierarchy_item_model.dart';
import 'package:aakash_s_application1/presentation/shopping_screen/models/shopping_model.dart';
part 'shopping_event.dart';
part 'shopping_state.dart';

/// A bloc that manages the state of a Shopping according to the event that is dispatched to it.
class ShoppingBloc extends Bloc<ShoppingEvent, ShoppingState> {
  ShoppingBloc(ShoppingState initialState) : super(initialState) {
    on<ShoppingInitialEvent>(_onInitialize);
  }

  List<ViewhierarchyItemModel> fillViewhierarchyItemList() {
    return [
      ViewhierarchyItemModel(
          topiName: "Purbeli Dhaka Topi",
          price: "Rs. 2000",
          location: "Sydney",
          additionalImage2: ImageConstant.imgMoreHorizFill,
          topiName1: "Purbeli Dhaka Topi",
          price1: "20",
          location1: "Sydney")
    ];
  }

  _onInitialize(
    ShoppingInitialEvent event,
    Emitter<ShoppingState> emit,
  ) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
    ));
    emit(state.copyWith(
        shoppingModelObj: state.shoppingModelObj?.copyWith(
      viewhierarchyItemList: fillViewhierarchyItemList(),
    )));
  }
}
