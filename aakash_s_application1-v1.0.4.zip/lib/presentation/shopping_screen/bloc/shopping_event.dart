// ignore_for_file: must_be_immutable

part of 'shopping_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///Shopping widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class ShoppingEvent extends Equatable {}

/// Event that is dispatched when the Shopping widget is first created.
class ShoppingInitialEvent extends ShoppingEvent {
  @override
  List<Object?> get props => [];
}
