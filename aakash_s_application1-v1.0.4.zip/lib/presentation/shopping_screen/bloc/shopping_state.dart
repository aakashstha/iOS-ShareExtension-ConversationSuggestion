// ignore_for_file: must_be_immutable

part of 'shopping_bloc.dart';

/// Represents the state of Shopping in the application.
class ShoppingState extends Equatable {
  ShoppingState({
    this.searchController,
    this.shoppingModelObj,
  });

  TextEditingController? searchController;

  ShoppingModel? shoppingModelObj;

  @override
  List<Object?> get props => [
        searchController,
        shoppingModelObj,
      ];
  ShoppingState copyWith({
    TextEditingController? searchController,
    ShoppingModel? shoppingModelObj,
  }) {
    return ShoppingState(
      searchController: searchController ?? this.searchController,
      shoppingModelObj: shoppingModelObj ?? this.shoppingModelObj,
    );
  }
}
