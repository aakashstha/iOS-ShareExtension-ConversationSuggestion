import '../../../core/app_export.dart';

/// This class is used in the [viewhierarchy_item_widget] screen.
class ViewhierarchyItemModel {
  ViewhierarchyItemModel({
    this.topiName,
    this.price,
    this.location,
    this.additionalImage2,
    this.topiName1,
    this.price1,
    this.location1,
    this.id,
  }) {
    topiName = topiName ?? "Purbeli Dhaka Topi";
    price = price ?? "Rs. 2000";
    location = location ?? "Sydney";
    additionalImage2 = additionalImage2 ?? ImageConstant.imgMoreHorizFill;
    topiName1 = topiName1 ?? "Purbeli Dhaka Topi";
    price1 = price1 ?? "20";
    location1 = location1 ?? "Sydney";
    id = id ?? "";
  }

  String? topiName;

  String? price;

  String? location;

  String? additionalImage2;

  String? topiName1;

  String? price1;

  String? location1;

  String? id;
}
