import '../models/viewhierarchy_item_model.dart';
import 'package:aakash_s_application1/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ViewhierarchyItemWidget extends StatelessWidget {
  ViewhierarchyItemWidget(
    this.viewhierarchyItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ViewhierarchyItemModel viewhierarchyItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      margin: EdgeInsets.all(0),
      color: theme.colorScheme.onPrimary.withOpacity(1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Container(
        height: 200.v,
        width: 180.h,
        decoration: AppDecoration.fillOnPrimary.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder10,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.center,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 10.h,
                  right: 4.h,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgDarkAzaleaPur,
                      height: 110.v,
                      width: 160.h,
                    ),
                    SizedBox(height: 11.v),
                    Text(
                      viewhierarchyItemModelObj.topiName!,
                      style: theme.textTheme.bodySmall,
                    ),
                    SizedBox(height: 2.v),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(bottom: 4.v),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: Text(
                                  viewhierarchyItemModelObj.price!,
                                  style: theme.textTheme.labelLarge,
                                ),
                              ),
                              SizedBox(height: 12.v),
                              Text(
                                viewhierarchyItemModelObj.location!,
                                style: theme.textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        CustomImageView(
                          imagePath: ImageConstant.imgAddShoppingCa,
                          height: 26.adaptSize,
                          width: 26.adaptSize,
                          margin: EdgeInsets.only(
                            top: 13.v,
                            bottom: 7.v,
                          ),
                        ),
                        CustomImageView(
                          imagePath:
                              viewhierarchyItemModelObj?.additionalImage2,
                          height: 40.adaptSize,
                          width: 40.adaptSize,
                          margin: EdgeInsets.only(
                            left: 7.h,
                            top: 6.v,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Container(
                padding: EdgeInsets.all(9.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadiusStyle.roundedBorder10,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgDarkAzaleaPur,
                      height: 110.v,
                      width: 160.h,
                    ),
                    SizedBox(height: 11.v),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        viewhierarchyItemModelObj.topiName1!,
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                    SizedBox(height: 1.v),
                    Padding(
                      padding: EdgeInsets.only(right: 2.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                viewhierarchyItemModelObj.price1!,
                                style: theme.textTheme.labelLarge,
                              ),
                              SizedBox(height: 12.v),
                              Text(
                                viewhierarchyItemModelObj.location1!,
                                style: theme.textTheme.bodySmall,
                              ),
                            ],
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.imgAddShoppingCa,
                            height: 26.adaptSize,
                            width: 26.adaptSize,
                            margin: EdgeInsets.only(
                              top: 13.v,
                              bottom: 2.v,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
