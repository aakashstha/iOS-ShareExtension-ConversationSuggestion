import 'bloc/login_bloc.dart';
import 'models/login_model.dart';
import 'package:aakash_s_application1/core/app_export.dart';
import 'package:aakash_s_application1/core/utils/validation_functions.dart';
import 'package:aakash_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:aakash_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:aakash_s_application1/widgets/custom_elevated_button.dart';
import 'package:aakash_s_application1/widgets/custom_outlined_button.dart';
import 'package:aakash_s_application1/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:aakash_s_application1/domain/googleauth/google_auth_helper.dart';
import 'package:aakash_s_application1/domain/facebookauth/facebook_auth_helper.dart';

// ignore_for_file: must_be_immutable
class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginBloc>(
        create: (context) => LoginBloc(LoginState(loginModelObj: LoginModel()))
          ..add(LoginInitialEvent()),
        child: LoginScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 19.h, vertical: 17.v),
                            child: Column(children: [
                              SizedBox(height: 36.v),
                              _buildEmail(context),
                              SizedBox(height: 15.v),
                              _buildPassword(context),
                              SizedBox(height: 50.v),
                              _buildSignIn(context),
                              SizedBox(height: 16.v),
                              Align(
                                  alignment: Alignment.centerRight,
                                  child: Padding(
                                      padding: EdgeInsets.only(right: 6.h),
                                      child: Text("msg_forgot_password".tr,
                                          style: CustomTextStyles
                                              .bodyLargeBlack900))),
                              SizedBox(height: 57.v),
                              Divider(indent: 13.h, endIndent: 13.h),
                              SizedBox(height: 21.v),
                              Text("msg_don_t_have_an_account".tr,
                                  style: CustomTextStyles.bodyLargeBluegray400),
                              SizedBox(height: 12.v),
                              _buildSignInWithGoogle(context),
                              SizedBox(height: 10.v),
                              _buildSignInWithFacebook(context),
                              SizedBox(height: 51.v),
                              RichText(
                                  text: TextSpan(children: [
                                    TextSpan(
                                        text: "lbl_new_to_auspaal".tr,
                                        style: CustomTextStyles
                                            .bodyLargeBlack90018),
                                    TextSpan(
                                        text: "lbl_sign_up".tr,
                                        style: CustomTextStyles.bodyLargePrimary
                                            .copyWith(
                                                decoration:
                                                    TextDecoration.underline))
                                  ]),
                                  textAlign: TextAlign.left)
                            ])))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        centerTitle: true, title: AppbarTitle(text: "lbl_welcome".tr));
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return BlocSelector<LoginBloc, LoginState, TextEditingController?>(
        selector: (state) => state.emailController,
        builder: (context, emailController) {
          return CustomTextFormField(
              controller: emailController,
              hintText: "lbl_email".tr,
              textInputType: TextInputType.emailAddress,
              validator: (value) {
                if (value == null || (!isValidEmail(value, isRequired: true))) {
                  return "err_msg_please_enter_valid_email".tr;
                }
                return null;
              });
        });
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(builder: (context, state) {
      return CustomTextFormField(
          controller: state.passwordController,
          hintText: "lbl_password".tr,
          textInputAction: TextInputAction.done,
          textInputType: TextInputType.visiblePassword,
          suffix: InkWell(
              onTap: () {
                context.read<LoginBloc>().add(ChangePasswordVisibilityEvent(
                    value: !state.isShowPassword));
              },
              child: Container(
                  margin: EdgeInsets.fromLTRB(30.h, 13.v, 15.h, 13.v),
                  child: CustomImageView(
                      imagePath: ImageConstant.imgVisibilityblack24dp1,
                      height: 24.adaptSize,
                      width: 24.adaptSize))),
          suffixConstraints: BoxConstraints(maxHeight: 50.v),
          validator: (value) {
            if (value == null || (!isValidPassword(value, isRequired: true))) {
              return "err_msg_please_enter_valid_password".tr;
            }
            return null;
          },
          obscureText: state.isShowPassword,
          contentPadding: EdgeInsets.only(left: 15.h, top: 15.v, bottom: 15.v));
    });
  }

  /// Section Widget
  Widget _buildSignIn(BuildContext context) {
    return CustomElevatedButton(
        height: 56.v,
        text: "lbl_sign_in".tr,
        margin: EdgeInsets.symmetric(horizontal: 3.h),
        buttonTextStyle: CustomTextStyles.bodyLargeRobotoOnPrimary);
  }

  /// Section Widget
  Widget _buildSignInWithGoogle(BuildContext context) {
    return CustomOutlinedButton(
        text: "msg_sign_in_with_google".tr,
        margin: EdgeInsets.symmetric(horizontal: 13.h),
        leftIcon: Container(
            margin: EdgeInsets.only(right: 10.h),
            child: CustomImageView(
                imagePath: ImageConstant.img26305852415481419341281,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        onPressed: () {
          onTapSignInWithGoogle(context);
        });
  }

  /// Section Widget
  Widget _buildSignInWithFacebook(BuildContext context) {
    return CustomOutlinedButton(
        text: "msg_sign_in_with_facebook".tr,
        margin: EdgeInsets.symmetric(horizontal: 13.h),
        leftIcon: Container(
            margin: EdgeInsets.only(right: 10.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgAkariconsfacebookfill,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        onPressed: () {
          onTapSignInWithFacebook(context);
        });
  }

  onTapSignInWithGoogle(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
        //TODO Actions to be performed after signin
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('user data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }

  onTapSignInWithFacebook(BuildContext context) async {
    await FacebookAuthHelper().facebookSignInProcess().then((facebookUser) {
      //TODO Actions to be performed after signin
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }
}
