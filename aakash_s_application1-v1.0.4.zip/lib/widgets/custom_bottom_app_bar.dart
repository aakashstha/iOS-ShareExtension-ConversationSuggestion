import 'package:aakash_s_application1/core/app_export.dart';
import 'package:flutter/material.dart';

class CustomBottomAppBar extends StatefulWidget {
  CustomBottomAppBar({this.onChanged});

  Function(BottomBarEnum)? onChanged;

  @override
  CustomBottomAppBarState createState() => CustomBottomAppBarState();
}

class CustomBottomAppBarState extends State<CustomBottomAppBar> {
  List<BottomMenuModel> bottomMenuList = [
    BottomMenuModel(
        icon: ImageConstant.imgNavHome,
        activeIcon: ImageConstant.imgNavHome,
        title: "lbl_home".tr,
        type: BottomBarEnum.Home,
        isSelected: true),
    BottomMenuModel(
      icon: ImageConstant.imgNavChats,
      activeIcon: ImageConstant.imgNavChats,
      title: "lbl_chats".tr,
      type: BottomBarEnum.Chats,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavActivity,
      activeIcon: ImageConstant.imgNavActivity,
      title: "lbl_activity".tr,
      type: BottomBarEnum.Activity,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavProfile,
      activeIcon: ImageConstant.imgNavProfile,
      title: "lbl_profile".tr,
      type: BottomBarEnum.Profile,
    )
  ];

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: CircularNotchedRectangle(),
      child: SizedBox(
        height: 24.v,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(
            bottomMenuList.length,
            (index) {
              return InkWell(
                onTap: () {
                  for (var element in bottomMenuList) {
                    element.isSelected = false;
                  }
                  bottomMenuList[index].isSelected = true;
                  widget.onChanged?.call(bottomMenuList[index].type);
                  setState(() {});
                },
                child: bottomMenuList[index].isSelected
                    ? Container(
                        decoration: AppDecoration.fillOnPrimary,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 8.v),
                              decoration: AppDecoration.fillOnPrimary,
                              child: CustomImageView(
                                imagePath: bottomMenuList[index].activeIcon,
                                height: 16.v,
                                width: 18.h,
                                color: theme.colorScheme.primary,
                                margin: EdgeInsets.fromLTRB(2.h, 3.v, 3.h, 4.v),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(bottom: 8.v),
                              child: Text(
                                bottomMenuList[index].title ?? "",
                                style: CustomTextStyles.labelLargeRobotoPrimary
                                    .copyWith(
                                  color: theme.colorScheme.primary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(
                        decoration: AppDecoration.fillOnPrimary,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            CustomImageView(
                              imagePath: bottomMenuList[index].icon,
                              height: 24.adaptSize,
                              width: 24.adaptSize,
                              color: appTheme.gray40001,
                              margin: EdgeInsets.only(top: 8.v),
                            ),
                            Padding(
                              padding: EdgeInsets.only(bottom: 8.v),
                              child: Text(
                                bottomMenuList[index].title ?? "",
                                style: CustomTextStyles
                                    .labelLargeRobotoGray40001
                                    .copyWith(
                                  color: appTheme.gray40001,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
              );
            },
          ),
        ),
      ),
    );
  }
}

enum BottomBarEnum {
  Home,
  Chats,
  Activity,
  Profile,
}

class BottomMenuModel {
  BottomMenuModel({
    required this.icon,
    required this.activeIcon,
    this.title,
    required this.type,
    this.isSelected = false,
  });

  String icon;

  String activeIcon;

  String? title;

  BottomBarEnum type;

  bool isSelected;
}

class DefaultWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.all(10),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Please replace the respective Widget here',
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
