class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Login images
  static String imgVisibilityblack24dp1 =
      '$imagePath/img_visibilityblack24dp_1.svg';

  static String img26305852415481419341281 =
      '$imagePath/img_2630585241548141934128_1.png';

  static String imgAkariconsfacebookfill =
      '$imagePath/img_akariconsfacebookfill.svg';

  // Shopping images
  static String imgBack = '$imagePath/img_back.svg';

  static String imgDarkAzaleaPur = '$imagePath/img_dark_azalea_pur.png';

  static String imgAddShoppingCa = '$imagePath/img_add_shopping_ca.svg';

  static String imgMoreHorizFill = '$imagePath/img_more_horiz_fill.svg';

  // Common images
  static String imgVector = '$imagePath/img_vector.svg';

  static String imgSearchblack24dp1 = '$imagePath/img_searchblack24dp_1.svg';

  static String imgImg11311 = '$imagePath/img_img_1131_1.png';

  static String imgStorefrontFill = '$imagePath/img_storefront_fill.svg';

  static String imgEngineeringFil = '$imagePath/img_engineering_fil.svg';

  static String imgHotelFill0Wgh = '$imagePath/img_hotel_fill0_wgh.svg';

  static String imgWorkFill0Wght = '$imagePath/img_work_fill0_wght.svg';

  static String imgComputerFill0 = '$imagePath/img_computer_fill0.svg';

  static String imgNavChats = '$imagePath/img_nav_chats.svg';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  static String imgNavProfile = '$imagePath/img_nav_profile.svg';

  static String imgNavActivity = '$imagePath/img_nav_activity.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
